<?php
include '../koneksi.php';

$id_pengaduan = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($id_pengaduan)) {
    echo "<script>alert('ID Pengaduan tidak ditemukan.'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
    exit;
}


$sql_update = "UPDATE pengaduan SET status='Selesai' WHERE id_pengaduan='$id_pengaduan'";
$data_update = mysqli_query($koneksi, $sql_update);

if ($data_update) {
    $tanggapan = 'Terimakasih sudah melaporkan, laporan anda sudah ditangani oleh pihak kami.';
    $tgl_tanggapan = date('Y-m-d');


    $check_tanggapan = mysqli_query($koneksi, "SELECT * FROM tanggapan WHERE id_pengaduan='$id_pengaduan'");
    
    if (mysqli_num_rows($check_tanggapan) == 0) {

        $query_insert = "INSERT INTO tanggapan (id_pengaduan, tanggapan, tgl_tanggapan) VALUES ('$id_pengaduan', '$tanggapan', '$tgl_tanggapan')";
        if (mysqli_query($koneksi, $query_insert)) {
            echo "<script>alert('Laporan telah ditangani dan tanggapan berhasil ditambahkan.'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan tanggapan.'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
        }
    } else {
       
        echo "<script>alert('Berhasil Memperbarui Status.'); window.location.href='petugas.php?url=verifikasi_pengaduan';</script>";
    }
} else {
    echo "<script>alert('Gagal memperbarui status pengaduan.'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
}
?>
