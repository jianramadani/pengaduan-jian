
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Laporan</h6>
    </div>
    <div class="card-body" style="font-size: 14px">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID Pengaduan</th>
                        <th>Tgl Pengaduan</th>
                        <th>NIK</th>
                        <th>Isi Laporan</th>
                        <th>Tanggapan</th>
                        <th>Foto</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include '../koneksi.php';
                    if (isset($_GET['id'])) {
                        $id = $_GET['id'];
                        $sql = "SELECT * FROM pengaduan, tanggapan WHERE tanggapan.id_pengaduan='$id' AND tanggapan.id_pengaduan=pengaduan.id_pengaduan";
                    } else {
                        $sql = "SELECT * FROM pengaduan, tanggapan WHERE tanggapan.id_pengaduan=pengaduan.id_pengaduan";
                    }

                    $query = mysqli_query($koneksi, $sql);
                    $no = 1;
                    while ($data = mysqli_fetch_array($query)) { ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $data['Tgl_pengaduan']; ?></td>
                            <td><?= $data['nik']; ?></td> 
                            <td><?= $data['isi_laporan']; ?></td>
                            <td><?= $data['tanggapan']; ?></td>
                            <td>
                                <?php if (!empty($data['foto'])) { ?>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modalFoto<?= $data['id_pengaduan']; ?>">
                                        Lihat Foto
                                    </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="modalFoto<?= $data['id_pengaduan']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Foto Pengaduan</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body text-center">
                                                        <img src="../foto/<?= $data['foto']; ?>" alt="Foto Pengaduan" class="img-fluid">
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                <?php } else { ?>
                                    <span class="text-danger">Tidak ada foto</span>
                                <?php } ?>
                            </td>
                            <td>
                                <?php if ($data['status'] == 'Proses') { ?>
                                    <span class="btn btn-primary">Proses</span>
                                <?php } elseif ($data['status'] == 'Ditolak') { ?>
                                    <span class="btn btn-danger">Ditolak</span>
                                <?php } else { ?>
                                    <span class="btn btn-success">Selesai</span>
                                <?php } ?>
                            </td>
                            <td>
                                <?php if ($data['status'] == 'Proses') { ?>
                                    <a href="?url=selesai&id=<?= $data['id_pengaduan']; ?>" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fa fa-check"></i>
                                        </span>
                                        <span class="text">Selesai</span>
                                    </a>
                                <?php } else { ?>
                                    <span> </span>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
   
