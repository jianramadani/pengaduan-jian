<?php
//login session, gabisa 2 login dalam 1 browser.
session_start();

if (isset($_SESSION['nama'])) {
    echo "<script>alert('Anda sedang login sebagai ".$_SESSION['nama'].", silahkan logout dari ".$_SESSION['nama']." terlebih dahulu untuk memulai sesi ini.'); window.location.assign('index.php'); </script>";
    exit;
}



include 'koneksi.php';
$nik = $_POST['nik'];
$password = $_POST['password'];
$remember = isset($_POST['remember']);/*variable buat fitur remember me*/

$sql = "SELECT * FROM masyarakat WHERE nik='$nik'";
$query = mysqli_query($koneksi, $sql);

if (mysqli_num_rows($query) > 0) {
    $data = mysqli_fetch_array($query);


    //buat mencegah multi-login (START)
    $sql_cek_login = "SELECT * FROM masyarakat WHERE nik='$nik' AND is_logged_in=1";
    $query_cek_login = mysqli_query($koneksi, $sql_cek_login);

    if(mysqli_num_rows($query_cek_login) > 0) {
        echo "<script>alert('Akun ini sedang digunakan. Logout terlebih dahulu untuk memulai sesi ini.'); window.location.assign('index.php'); </script>";
        exit;
    }
    
    if (password_verify($password, $data['password']))/*buat indentifikasi password yang udah dihash*/ {

        if ($data['is_logged_in'] == 1) {
            echo "<script>alert('Login gagal. Akun ini sedang login, silahkan logout sesi sebelumnya untuk memulai sesi ini.'); window.location.assign('index.php'); </script>";
        }/*buat mencegah multi-login (END)*/ 
        
        else {
            $_SESSION['nik'] = $nik;
            $_SESSION['nama'] = $data['nama'];
            $_SESSION['username'] = $data['username'];


            //kalau remember me dicentang, simpan data cookie berupa nik dan nama dengan durasi 30hari (START)
            if ($remember) {
                setcookie('nik', $nik, time() + (30 * 24 * 60 * 60), "/");
                setcookie('nama', $data['nama'], time() + (30 * 24 * 60 * 60), "/");
            }
            //kalau remember me dicentang, simpan data cookie berupa nik dan nama dengan durasi 30hari (END)

            $update_sql = "UPDATE masyarakat SET is_logged_in=1 WHERE nik='$nik'"; //kalau user berhasil login bakal ngerubah value dari 0 jadi 1, is_logged_in = 1(user lagi login) atau is_logged_in = 0(user tidak login).
            mysqli_query($koneksi, $update_sql);

            header('location: masyarakat.php');
        }
    } else {

        echo "<script>alert('Maaf Anda Gagal Login. Password tidak valid.'); window.location.assign('index.php'); </script>";
    }
} else {
    echo "<script>alert('Maaf Anda Gagal Login. NIK tidak ditemukan.'); window.location.assign('index.php'); </script>";
}

