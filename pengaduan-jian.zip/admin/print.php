<?php
    require('../library/fpdf.php');
    include '../koneksi.php';

    $tgl_awal = isset($_GET['tgl_awal']) ? $_GET['tgl_awal'] : null;
    $tgl_akhir = isset($_GET['tgl_akhir']) ? $_GET['tgl_akhir'] : null;
    $status = isset($_GET['status']) ? $_GET['status'] : null;

    $pdf = new FPDF('L', 'mm', 'A4');
    $pdf->AddPage();

    // Set font untuk judul
    $pdf->SetFont('Times', 'B', 13);
    $pdf->Cell(275, 10, 'DATA PENGADUAN MASYARAKAT', 0, 0, 'C');
    $pdf->Ln(15);

    // Set font untuk header tabel
    $pdf->SetFont('Times', 'B', 9);
    $pdf->Cell(10, 7, 'NO', 1, 0, 'C');
    $pdf->Cell(30, 7, 'Id_pengaduan', 1, 0, 'C');
    $pdf->Cell(40, 7, 'Tgl_pengaduan', 1, 0, 'C');
    $pdf->Cell(30, 7, 'NIK', 1, 0, 'C');
    $pdf->Cell(80, 7, 'Isi Laporan', 1, 0, 'C');
    $pdf->Cell(45, 7, 'Foto', 1, 0, 'C');
    $pdf->Cell(35, 7, 'Status', 1, 1, 'C');

    // Query SQL berdasarkan status
    if ($status === '1' || $status === null) {
        $sql = "SELECT * FROM pengaduan WHERE tgl_pengaduan BETWEEN '$tgl_awal' AND '$tgl_akhir'";
    } else {
        $sql = "SELECT * FROM pengaduan WHERE status='$status' AND tgl_pengaduan BETWEEN '$tgl_awal' AND '$tgl_akhir'";
    }

    $query = mysqli_query($koneksi, $sql);
    $no = 1;

    while ($data = mysqli_fetch_array($query)) {
        $pdf->Cell(10, 6, $no++, 1, 0, 'C');
        $pdf->Cell(30, 6, $data['id_pengaduan'], 1, 0, 'C');
        $pdf->Cell(40, 6, $data['Tgl_pengaduan'], 1, 0, 'C');
        $pdf->Cell(30, 6, $data['nik'], 1, 0, 'C');
        
        // MultiCell digunakan untuk kolom "Isi Laporan"
        $x = $pdf->GetX();
        $y = $pdf->GetY();
        $pdf->MultiCell(80, 6, $data['isi_laporan'], 1, 'L');
        $pdf->SetXY($x + 80, $y); // Kembali ke posisi berikutnya setelah MultiCell

        $pdf->Cell(45, 6, $data['foto'], 1, 0, 'C');
        $pdf->Cell(35, 6, $data['status'], 1, 1, 'C');
    }

    $pdf->Output();
    ?>
