<?php

$id = $_GET['id'];
if (empty($id)) {
    header("Location:masyarakat.php");
    exit; 
}

include 'koneksi.php';

$query_pengaduan = mysqli_query($koneksi, "SELECT * FROM pengaduan WHERE id_pengaduan='$id'");
$data_pengaduan = mysqli_fetch_array($query_pengaduan);

$query_tanggapan = mysqli_query($koneksi, "SELECT * FROM tanggapan WHERE id_pengaduan='$id'");
$data_tanggapan = mysqli_fetch_array($query_tanggapan);

?>

<div class="card shadow">
    <div class="card-header">
        <a href="?url=lihat-pengaduan" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-50">
                <i class="fa fa-arrow-left"></i>
            </span>
            <span class="text">Kembali</span>
        </a>
    </div>
    <div class="card-body">
        <form method="post" action="proses-pengaduan.php" enctype="multipart/form-data">
            <!-- Bagian Pengaduan -->
            <div class="form-group">
                <label style="font-size: 14px;">Tgl Pengaduan</label>
                <input type="text" name="tgl_pengaduan" class="form-control" readonly value="<?= $data_pengaduan['Tgl_pengaduan']; ?>">
            </div>
            <div class="form-group">
                <label style="font-size: 14px;">Isi Laporan</label>
                <textarea name="isi_laporan" class="form-control" readonly><?= $data_pengaduan['isi_laporan']; ?></textarea>
            </div>
            <div class="form-group">
                <label style="font-size: 14px;">Foto</label>
                <img class="img-thumbnail" src="foto/<?= $data_pengaduan['foto'] ?>" width="300">
            </div>
            <div class="form-group">
                <label style="font-size: 14px;">Tanggapan Admin</label>
                <?php if (!empty($data_tanggapan)) : ?>
                    <textarea name="tanggapan" class="form-control" readonly><?= $data_tanggapan['tanggapan']; ?></textarea>
                <?php else : ?>
                    <textarea name="tanggapan" class="form-control" readonly>Maaf. Laporan anda belum diverifikasi oleh admin.</textarea>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
