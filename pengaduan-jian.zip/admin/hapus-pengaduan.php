<?php
$id = $_GET['id'];
if (empty($id)) {
    header("Location:masyarakat.php");
    exit; // it's a good practice to exit after a header redirection
}
include '../koneksi.php';
$query = mysqli_query($koneksi, "DELETE FROM pengaduan WHERE id_pengaduan='$id'");

mysqli_close($koneksi);

?>
 