<?php
session_start();
include 'koneksi.php';

$nik = $_SESSION['nik'];


$update_sql = "UPDATE masyarakat SET is_logged_in=0 WHERE nik='$nik'"; //ngeganti value menjadi 0
mysqli_query($koneksi, $update_sql);


session_destroy(); //hapus semua sesi yang ada

//langsung buat durasi cookie yang kesimpan menjadi expired(START)
if (isset($_COOKIE['nik'])) {
    setcookie('nik', '', time() - 3600, '/'); 
}
if (isset($_COOKIE['nama'])) {
    setcookie('nama', '', time() - 3600, '/'); 
}
//langsung buat durasi cookie yang kesimpan menjadi expired(END)

header('location: index.php');
?>
