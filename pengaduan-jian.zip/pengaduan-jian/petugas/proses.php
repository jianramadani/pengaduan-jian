<?php
$id = $_GET['id'];
if (empty($id)) {
    header("Location:masyarakat.php");
    exit;
}

include '../koneksi.php';
$id_pengaduan = isset($_GET['id']) ? $_GET['id'] : $_POST['id_pengaduan'];
$sql = "UPDATE pengaduan SET status='Proses' WHERE id_pengaduan='$id_pengaduan'";
$data = mysqli_query($koneksi, $sql);

if ($data) {
    
    $tanggapan ='Terimakasih sudah melapor!!, laporan anda akan segera ditangani.';
    $tgl_tanggapan = date('d-m-Y'); 

    $query = "INSERT INTO tanggapan (id_pengaduan, tanggapan, tgl_tanggapan) VALUES ('$id_pengaduan', '$tanggapan', '$tgl_tanggapan')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Laporan Telah Diverifikasi!'); window.location.href='petugas.php?url=verifikasi_pengaduan';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan tanggapan.'); window.location.href='petugas.php?url=verifikasi_pengaduan';</script>";
    }
} else {
    echo "<script>alert('Gagal memperbarui status laporan.'); window.location.href='petyugas.php?url=verifikasi_pengaduan';</script>";
}
?>
