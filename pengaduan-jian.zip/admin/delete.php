<?php
include '../koneksi.php';

$id_pengaduan = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($id_pengaduan)) {
    echo "<script>alert('ID Pengaduan tidak ditemukan.'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
    exit;
}

$sql_delete_tanggapan = "DELETE FROM tanggapan WHERE id_pengaduan='$id_pengaduan'";
$data_delete_tanggapan = mysqli_query($koneksi, $sql_delete_tanggapan);

$sql_delete_pengaduan = "DELETE FROM pengaduan WHERE id_pengaduan='$id_pengaduan'";
$data_delete_pengaduan = mysqli_query($koneksi, $sql_delete_pengaduan);

if ($data_delete_pengaduan) {
    echo "<script>alert('Data berhasil dihapus.'); window.location.href='admin.php?url=lihat-pengaduan';</script>";
} else {
    echo "<script>alert('Gagal menghapus data.'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
}
?>
